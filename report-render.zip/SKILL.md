---
name: report-render
description: Renders the RFP check into a single self-contained HTML report — per-respondent extracts against each Requirement ID, additional notes, and a comparison table across respondents with the coverage receipt. Use after responses have been checked, when the user asks for the report, the summary, the comparison or the output file.
---

# Render the report

Turns `requirements.json` and `coverage.json` into one self-contained `.html`
file. Deterministic: the same inputs produce an identically structured report
every run, in every category.

## Step 1 — render

Run `scripts/render_report.py` with the register, the coverage file and the
template in `templates/report.html`.

## Step 2 — structure, in this order

1. **Header** — RFP reference, issue and deadline dates, respondent names,
   and the **coverage receipt**.
2. **Coverage at a glance** — verdict counts per respondent, plus how many of
   their cells are gate-blocked. A plain table, no cards.
3. **Unresolved thresholds** — every requirement the RFP left open, what is
   missing, and the note that respondents *did* answer these; only the pass/fail
   test is blocked. This comes before any result.
4. **Per-respondent extracts** — for each respondent, every Requirement ID with
   its verdict, the quoted extract and where it was found, then that
   respondent's `[additional note]` items in a visually distinct block.
5. **Comparison table** — requirements down the side, respondents across the
   top. Each cell carries the verdict, a **short answer**, and a gate marker
   where the threshold cannot be adjudicated: the stated value
   where one was extracted, otherwise the first clause of the quoted extract,
   condensed to roughly 70 characters. A reader should be able to compare the
   substance across respondents without scrolling back to the extracts. Cells
   with verdict `absent` show the verdict alone — there is nothing to show.

Extracts before comparison is deliberate. A summary is only trustworthy when
the evidence behind it is already on the page.

## Step 3 — hand it over

Tell the user the file is ready and **tell them to save it**. Files generated
in a session are downloadable during that session only and are not retained
afterwards.

If the report needs to land somewhere durable — a SharePoint library, a case
record — say so plainly: that is not something this agent can do, and it is a
harness decision rather than a change to this skill.

## Presentation rules

- Verdicts render as rounded tinted chips with a consistent colour everywhere:
  green `answered`; amber `partial` and `flag`; red `evasive`, `absent` and
  `deviation`; grey `not evaluable`. Colour is never the only signal — every
  chip carries its label.
- The comparison table shows verdict **plus** the short answer. The short form
  never replaces the full extract in the per-respondent section — it points at
  it. Never condense so far that the meaning inverts: "no open actions" must
  not become "open actions".
- Every extract is quoted verbatim, with its location.
- `[additional note]` items are visually separated from register results and
  never counted in coverage totals.
- Print the receipt arithmetic in the header, not a footnote.
- No charts, no scoring, no ranking.

## Do not

- Do not rank respondents or name a preferred supplier. The report presents;
  the procurement manager decides.
- Do not compute a weighted score. The RFP's evaluation weights are unresolved
  until the user supplies them.
- Do not soften an `absent` or an `evasive` verdict in the prose summary.
- Do not comment on document quality, formatting or presentation. Content only.
