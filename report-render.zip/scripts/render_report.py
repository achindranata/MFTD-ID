#!/usr/bin/env python3
"""
Render the RFP check into one self-contained HTML report.

Standard library only - the skill sandbox has no network access and cannot
install packages at runtime.

Usage:
    python render_report.py --register requirements.json \
        --coverage coverage.json [--template templates/report.html] \
        [-o rfp-check-report.html]
"""

import argparse
import datetime as dt
import html
import json
import os
import sys

VERDICTS = ["answered", "partial", "evasive", "absent", "deviation",
            "flag", "not_evaluable"]
LABEL = {"not_evaluable": "not evaluable"}


def esc(s):
    return html.escape(str(s if s is not None else ""))


def vspan(v):
    v = (v or "absent").lower()
    return '<span class="v v-%s">%s</span>' % (esc(v), esc(LABEL.get(v, v)))


def gate_span(cell):
    """Marker for a threshold that cannot be adjudicated from the RFP."""
    if (cell or {}).get("gate") == "cannot_adjudicate":
        return "<span class='gate'>gate not adjudicable</span>"
    return ""


def short_answer(cell, limit=70):
    """Condensed answer for the comparison table.

    Prefers the stated value where one was extracted; otherwise condenses the
    quoted extract to its first clause. Returns "" where there is no answer to
    show, so the table displays the verdict alone.
    """
    if not cell:
        return ""
    if (cell.get("verdict") or "").lower() == "absent":
        return ""
    val = (cell.get("stated_value") or "").strip()
    if val:
        return val
    text = " ".join((cell.get("extract") or "").split())
    if not text:
        return ""
    for stop in (". ", "; ", " - "):
        i = text.find(stop)
        if 0 < i <= limit:
            text = text[:i]
            break
    if len(text) > limit:
        text = text[:limit].rsplit(" ", 1)[0] + "..."
    return text


def build_receipt(reg, cov):
    reqs = reg.get("requirements", [])
    cells = cov.get("cells", [])
    names = sorted({c["respondent"] for c in cells})
    counts = {v: 0 for v in VERDICTS}
    for c in cells:
        counts[c.get("verdict", "absent")] = counts.get(c.get("verdict", "absent"), 0) + 1
    expected = len(reqs) * max(len(names), 1)
    lines = [
        "%d requirements x %d respondents = %d cells; %d filled, %d empty"
        % (len(reqs), len(names), expected, len(cells), expected - len(cells)),
        "   " + " | ".join("%s %d" % (LABEL.get(v, v), counts.get(v, 0))
                           for v in VERDICTS if counts.get(v, 0)),
    ]
    if expected != len(cells):
        lines.append("   WARNING: grid incomplete - every requirement x respondent "
                     "must carry a verdict.")
    return "\n".join(lines)


def build_summary(reg, cov):
    """Per-respondent coverage counts - a plain table, no cards."""
    cells = cov.get("cells", [])
    names = sorted({c["respondent"] for c in cells})
    if not names:
        return ""
    cols = ["answered", "partial", "evasive", "absent", "deviation",
            "flag", "not_evaluable"]
    head = "".join("<th>%s</th>" % esc(LABEL.get(v, v)) for v in cols)
    rows = []
    for n in names:
        mine = [c for c in cells if c["respondent"] == n]
        tds = []
        for v in cols:
            k = sum(1 for c in mine if (c.get("verdict") or "") == v)
            tds.append("<td>%s</td>" % (k if k else "<span class='none'>-</span>"))
        gates = sum(1 for c in mine if c.get("gate") == "cannot_adjudicate")
        rows.append("<tr><td><b>%s</b></td>%s<td>%s</td></tr>"
                    % (esc(n), "".join(tds),
                       gates if gates else "<span class='none'>-</span>"))
    return ("<h2>Coverage at a glance</h2><table><caption>Verdict counts per "
            "respondent</caption><thead><tr><th>Respondent</th>%s"
            "<th>Gate blocked</th></tr></thead><tbody>%s</tbody></table>"
            % (head, "".join(rows)))


def build_not_evaluable(reg, cov=None):
    rows = [r for r in reg.get("requirements", []) if r.get("status") == "UNRESOLVED"]
    if not rows:
        return ""
    items = "".join(
        "<li><code>%s</code> &mdash; %s <span class='loc'>(%s)</span></li>"
        % (esc(r["id"]), esc(r.get("text", "")[:180]), esc(r.get("source", "")))
        for r in rows)
    return ("<div class='flagbox'><b>Thresholds the RFP left unresolved "
            "&mdash; %d requirement(s)</b>"
            "<p>Respondents answered these, and their stated values are reported "
            "in full. What cannot be determined is whether those values "
            "<em>pass</em> &mdash; the RFP sets no threshold to test them against. "
            "Supply the missing figures to adjudicate.</p><ul>%s</ul></div>"
            % (len(rows), items))


def build_extracts(reg, cov):
    order = [r["id"] for r in reg.get("requirements", [])]
    text = {r["id"]: r.get("text", "") for r in reg.get("requirements", [])}
    cells = cov.get("cells", [])
    names = sorted({c["respondent"] for c in cells})
    notes = cov.get("additional_notes", {})
    out = []
    for name in names:
        out.append("<h3>%s</h3>" % esc(name))
        out.append("<table><thead><tr><th style='width:7rem'>Requirement</th>"
                   "<th style='width:7rem'>Verdict</th><th>Extract</th></tr></thead><tbody>")
        by_id = {c["req_id"]: c for c in cells if c["respondent"] == name}
        for rid in order:
            c = by_id.get(rid)
            if not c:
                out.append("<tr><td><code>%s</code></td><td>%s</td>"
                           "<td class='quote'>No verdict recorded</td></tr>"
                           % (esc(rid), vspan("absent")))
                continue
            extract = esc(c.get("extract", "")) or "<i>nothing in the document "\
                                                   "addresses this requirement</i>"
            loc = c.get("location")
            detail = ""
            if c.get("required_value") or c.get("stated_value"):
                detail = ("<br><span class='loc'>stated: %s &nbsp;|&nbsp; required: %s</span>"
                          % (esc(c.get("stated_value")), esc(c.get("required_value"))))
            out.append(
                "<tr><td><code>%s</code><br><span class='loc'>%s</span></td>"
                "<td>%s</td><td class='quote'>%s%s%s</td></tr>"
                % (esc(rid), esc(text.get(rid, "")[:70]),
                   vspan(c.get("verdict")) + gate_span(c),
                   extract, detail,
                   ("<br><span class='loc'>%s</span>" % esc(loc)) if loc else ""))
        out.append("</tbody></table>")

        items = notes.get(name) or []
        if items:
            lis = "".join(
                "<li>%s%s</li>" % (
                    esc(i.get("item") if isinstance(i, dict) else i),
                    (" <span class='loc'>(%s)</span>" % esc(i["location"]))
                    if isinstance(i, dict) and i.get("location") else "")
                for i in items)
            out.append("<div class='notes'><h4>Additional notes &mdash; offered but "
                       "not requested</h4><ul>%s</ul></div>" % lis)
    return "\n".join(out)


def build_comparison(reg, cov):
    order = [r["id"] for r in reg.get("requirements", [])]
    text = {r["id"]: r.get("text", "") for r in reg.get("requirements", [])}
    cells = cov.get("cells", [])
    names = sorted({c["respondent"] for c in cells})
    idx = {(c["req_id"], c["respondent"]): c for c in cells}
    head = "".join("<th>%s</th>" % esc(n) for n in names)
    rows = []
    for rid in order:
        tds = []
        for n in names:
            c = idx.get((rid, n))
            if not c:
                tds.append("<td>%s</td>" % vspan("absent"))
                continue
            ans = short_answer(c)
            tds.append("<td>%s%s%s</td>" % (
                vspan(c.get("verdict")),
                ("<span class='ans'>%s</span>" % esc(ans)) if ans else "",
                gate_span(c)))
        rows.append("<tr><td><code>%s</code></td><td class='quote'>%s</td>%s</tr>"
                    % (esc(rid), esc(text.get(rid, "")[:90]), "".join(tds)))
    return ("<table><thead><tr><th style='width:6rem'>ID</th><th>Requirement</th>%s"
            "</tr></thead><tbody>%s</tbody></table>" % (head, "".join(rows)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--register", required=True)
    ap.add_argument("--coverage", required=True)
    ap.add_argument("--template",
                    default=os.path.join(os.path.dirname(__file__),
                                         "..", "templates", "report.html"))
    ap.add_argument("-o", "--out", default="rfp-check-report.html")
    a = ap.parse_args()

    for p in (a.register, a.coverage, a.template):
        if not os.path.exists(p):
            sys.exit("File not found: %s" % p)

    with open(a.register, encoding="utf-8") as fh:
        reg = json.load(fh)
    with open(a.coverage, encoding="utf-8") as fh:
        cov = json.load(fh)
    with open(a.template, encoding="utf-8") as fh:
        tpl = fh.read()

    names = sorted({c["respondent"] for c in cov.get("cells", [])})
    out = (tpl
           .replace("{{TITLE}}", "RFP response check &mdash; %s"
                    % esc(reg.get("rfp_ref", "")))
           .replace("{{RFP_REF}}", esc(reg.get("rfp_ref")))
           .replace("{{ISSUED}}", esc(reg.get("issued")))
           .replace("{{DEADLINE}}", esc(reg.get("deadline")))
           .replace("{{RESPONDENT_LIST}}", esc(", ".join(names)))
           .replace("{{RECEIPT}}", esc(build_receipt(reg, cov)))
           .replace("{{SUMMARY}}", build_summary(reg, cov))
           .replace("{{NOT_EVALUABLE}}", build_not_evaluable(reg, cov))
           .replace("{{EXTRACTS}}", build_extracts(reg, cov))
           .replace("{{COMPARISON}}", build_comparison(reg, cov))
           .replace("{{GENERATED}}",
                    dt.datetime.now().strftime("%d %B %Y, %H:%M")))

    with open(a.out, "w", encoding="utf-8") as fh:
        fh.write(out)

    print(build_receipt(reg, cov))
    print("\nReport written to %s" % a.out)
    print("Download it during this session - generated files are not retained "
          "after the session ends.")


if __name__ == "__main__":
    main()


