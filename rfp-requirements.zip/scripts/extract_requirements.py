#!/usr/bin/env python3
"""
Parse an issued RFP (.docx) into candidate requirement passages.

Standard library only - the skill sandbox has no network access and cannot
install packages at runtime.

Usage:
    python extract_requirements.py <rfp.docx> [-o candidates.json]

Emits candidate passages with stable IDs plus every unresolved placeholder
found. It does NOT decide what is a requirement - that judgement belongs to
the model, per SKILL.md step 2.
"""

import argparse
import json
import os
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

# Placeholder shapes seen in real issued RFPs.
PLACEHOLDER = re.compile(
    r"\[\s*(?:TBC|TBD|X+|\s*)\s*\]"          # [TBC] [TBD] [XX] [ ]
    r"|\[\s*Insert[^\]]*\]"                   # [Insert monthly volume]
    r"|\[\s*Any other[^\]]*\]",               # [Any other custom terms]
    re.IGNORECASE,
)

# Passages that plausibly carry an obligation.
OBLIGATION = re.compile(
    r"\b(must|shall|required|requirement|will not be|please provide|provide|"
    r"confirm|describe|state|summarize|summarise|disclose|identify|"
    r"elimination|pass/fail|mandatory|firm for)\b",
    re.IGNORECASE,
)

HEADING_NUM = re.compile(r"^\s*(?:Appendix\s+[A-Z]|Section\s+\d+|\d+\.)\s*", re.I)


def _text_of(node):
    return "".join(t.text or "" for t in node.iter(W + "t"))


def _style_of(node):
    p = node.find(W + "pPr")
    if p is None:
        return None
    s = p.find(W + "pStyle")
    return s.get(W + "val") if s is not None else None


def read_docx(path):
    """Yield (kind, style, text) in document order. kind is 'p' or 'cell'."""
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml")
    root = ET.fromstring(xml)
    body = root.find(W + "body")
    if body is None:
        return

    def walk(el, in_table=False):
        for child in el:
            tag = child.tag
            if tag == W + "p":
                txt = _text_of(child).strip()
                if txt:
                    yield ("cell" if in_table else "p", _style_of(child), txt)
            elif tag == W + "tbl":
                for row in child.findall(W + "tr"):
                    cells = []
                    for tc in row.findall(W + "tc"):
                        cells.append(" ".join(
                            _text_of(p).strip()
                            for p in tc.findall(W + "p")
                            if _text_of(p).strip()
                        ))
                    joined = " | ".join(c for c in cells if c)
                    if joined:
                        yield ("cell", None, joined)
            else:
                yield from walk(child, in_table)

    yield from walk(body)


def build(path):
    section = "Preamble"
    candidates = []
    placeholders = []
    order = 0

    for kind, style, text in read_docx(path):
        order += 1

        # Track the current section from headings or numbered leaders.
        is_heading = (style or "").lower().startswith("heading")
        if is_heading or (kind == "p" and HEADING_NUM.match(text) and len(text) < 120):
            section = text.strip()
            continue

        for m in PLACEHOLDER.finditer(text):
            placeholders.append({
                "token": m.group(0).strip(),
                "section": section,
                "context": text[:220],
                "order": order,
            })

        if OBLIGATION.search(text) and len(text) > 25:
            candidates.append({
                "cand_id": "C%03d" % (len(candidates) + 1),
                "section": section,
                "kind": kind,
                "text": text,
                "has_placeholder": bool(PLACEHOLDER.search(text)),
                "order": order,
            })

    return {
        "source_file": os.path.basename(path),
        "paragraph_count": order,
        "candidate_count": len(candidates),
        "placeholder_count": len(placeholders),
        "placeholders": placeholders,
        "candidates": candidates,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("rfp")
    ap.add_argument("-o", "--out", default="candidates.json")
    a = ap.parse_args()

    if not os.path.exists(a.rfp):
        sys.exit("File not found: %s" % a.rfp)

    result = build(a.rfp)
    with open(a.out, "w", encoding="utf-8") as fh:
        json.dump(result, fh, indent=2, ensure_ascii=False)

    print("Parsed %s" % result["source_file"])
    print("  paragraphs         : %d" % result["paragraph_count"])
    print("  candidate passages : %d" % result["candidate_count"])
    print("  placeholders found : %d" % result["placeholder_count"])
    if result["placeholders"]:
        print("\nUNRESOLVED - requirements touching these are NOT EVALUABLE:")
        for p in result["placeholders"]:
            print("  %-28s %s" % (p["token"], p["section"][:60]))
    print("\nWritten to %s" % a.out)


if __name__ == "__main__":
    main()
