---
name: rfp-requirements
description: Derives the requirement register from an issued RFP — every obligation a response must satisfy, each with a Requirement ID, source reference, check type and evaluation engine. Flags requirements whose thresholds the RFP left unresolved. Use when the user attaches an RFP and asks to check, evaluate or compare supplier responses against it, or asks what a given RFP actually requires.
---

# Derive the requirement register

You are reading the **baseline** — the issued RFP — and producing the register
that every downstream check runs against. Nothing else in this agent invents a
requirement; if it is not in the register, it is not evaluated.

## Step 1 — parse the RFP

Run `scripts/extract_requirements.py` against the attached RFP. It returns
candidate passages with stable IDs, and a list of unresolved placeholders it
detected by pattern (`[TBC]`, `[Insert ...]`, `[ ]`, `[Any other...]`).

The script finds candidates. It does not decide what is a requirement.

## Step 2 — decide what is a requirement

Read each candidate passage and keep it only if it imposes an obligation a
response can be measured against. Keep:

- Elimination / pass-fail conditions
- Submission requirements — things the response must contain
- Commercial terms the supplier must accept or state
- Questionnaire questions
- Evaluation criteria that require disclosed information

Discard background, context, timetable prose and boilerplate.

## Step 3 — assign IDs

Group by category so a reader can navigate the register:

| Prefix | Category |
|---|---|
| `ELIM-` | Elimination / pass-fail criteria |
| `REG-` | Regulatory and GMP |
| `QMS-` | Quality systems |
| `CAP-` | Capacity and supply |
| `REL-` | Relationship and references |
| `SUB-` | Subcontracting |
| `PRC-` | Pricing |
| `TERM-` | Commercial terms and conditions |
| `DRV-` | Derived checks (see Step 5) |

Number sequentially within each prefix, starting at 01.

## Step 4 — set the engine per requirement

Apply one test: **would two competent reviewers reading the same response reach
the identical answer?**

- Yes → `engine: script`. Write an `assert` expression against a named field.
  Thresholds, exact terms, stated figures, presence of a number.
- No → `engine: model`. Write a `question` and a `rubric` with explicit pass /
  fail / flag conditions, and set `evidence: required`.

## Step 5 — add derived checks

These are not written in the RFP but follow from it. Always include, where the
RFP provides the inputs:

- `DRV-01` minimum order quantity ÷ required monthly volume — months of
  inventory the buyer must absorb
- `DRV-02` proposed contract term vs the RFP's stated term
- `DRV-03` internal consistency within each response — a claim in one section
  contradicted by another
- `DRV-04` response date within the RFP's issue-to-deadline window

## Step 6 — flag what cannot be evaluated

For every placeholder the script found, set `"status": "UNRESOLVED"` on the
affected requirement and `null` on the value.

This is the most important behaviour in this skill. A requirement with an
unresolved threshold is **not evaluable**. Do not substitute a default, an
industry norm or the best value among the respondents. Report the values each
respondent stated and ask the user to supply the missing figure.

## Step 7 — confirm

Emit `requirements.json` and show the user:

- the count of requirements by category
- every `UNRESOLVED` requirement, and what is missing
- any RFP section you found no requirement in, so they can tell you if you
  missed one

Wait for confirmation before any checking begins.

## Output schema

```json
{
  "rfp_ref": "string",
  "issued": "YYYY-MM-DD",
  "deadline": "YYYY-MM-DD",
  "monthly_volume": null,
  "requirements": [
    { "id": "ELIM-01",
      "source": "Appendix A, Section 0",
      "text": "verbatim requirement text",
      "engine": "script",
      "assert": "lead_time_weeks <= {{lead_time_max}}",
      "status": "UNRESOLVED" },

    { "id": "ELIM-02",
      "source": "Appendix A, Section 0",
      "text": "verbatim requirement text",
      "engine": "model",
      "question": "No open regulatory actions, and no significant adverse outcome at the most recent inspection?",
      "rubric": { "pass": "no open action and a clean recent inspection",
                  "flag": "observations issued but since closed",
                  "fail": "open action, or a significant adverse outcome" },
      "evidence": "required" }
  ]
}
```

## Do not

- Do not carry requirements over from a previous RFP. Derive from the attached
  document every time.
- Do not merge two obligations into one requirement. If the text needs "and",
  it is two requirements.
- Do not drop a requirement because no respondent is likely to answer it. The
  silences are the point.
