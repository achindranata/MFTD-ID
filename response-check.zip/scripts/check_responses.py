#!/usr/bin/env python3
"""
Parse supplier responses, extract stated figures, run resolved threshold and
derived checks, and print the coverage grid.

Standard library only - the skill sandbox has no network access and cannot
install packages at runtime.

Usage:
    python check_responses.py --register requirements.json \
        --responses "Sabyn.docx" "Kristos.docx" "Annterra.docx" \
        [-o facts.json]

This script owns the deterministic half: passages, figures, thresholds,
derived checks and the completeness receipt. Mapping and grading belong to
the model, per SKILL.md steps 2-4.
"""

import argparse
import datetime as dt
import json
import os
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


# ---------------------------------------------------------------- parsing

def _text_of(node):
    return "".join(t.text or "" for t in node.iter(W + "t"))


def _style_of(node):
    p = node.find(W + "pPr")
    if p is None:
        return None
    s = p.find(W + "pStyle")
    return s.get(W + "val") if s is not None else None


def parse_docx(path):
    """Return passages with stable IDs. Styles used where present."""
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml")
    body = ET.fromstring(xml).find(W + "body")
    passages, section, n = [], "Front matter", 0
    if body is None:
        return passages

    def walk(el, in_table=False):
        nonlocal section, n
        for child in el:
            if child.tag == W + "p":
                txt = _text_of(child).strip()
                if not txt:
                    continue
                style = _style_of(child) or ""
                # Tier 1: real heading styles. Tier 2: short title-ish lines.
                if style.lower().startswith("heading") or (
                    not in_table and len(txt) < 70
                    and re.match(r"^(Section|Appendix|Q\d|Bid Summary|Cover Letter)", txt, re.I)
                ):
                    section = txt
                    continue
                n += 1
                passages.append({"pid": "P%03d" % n, "section": section,
                                 "text": txt, "in_table": in_table})
            elif child.tag == W + "tbl":
                for row in child.findall(W + "tr"):
                    cells = []
                    for tc in row.findall(W + "tc"):
                        cells.append(" ".join(
                            _text_of(p).strip() for p in tc.findall(W + "p")
                            if _text_of(p).strip()))
                    joined = " | ".join(c for c in cells if c)
                    if joined:
                        n += 1
                        passages.append({"pid": "P%03d" % n, "section": section,
                                         "text": joined, "in_table": True})
            else:
                walk(child, in_table)

    walk(body)
    return passages


# ---------------------------------------------------------------- figures

PATTERNS = {
    "unit_price":         r"\$\s*(\d+(?:\.\d{1,2})?)\s*(?:per unit|/unit)?",
    "lead_time_weeks":    r"(\d{1,3})\s*weeks?\s*(?:from contract|to first|lead)",
    "moq_units":          r"(?:minimum order quantity|MOQ)[^\d]{0,40}([\d,]{4,})",
    "monthly_commit":     r"(?:we confirm|confirm(?:ed)?|committed?)[^\d]{0,30}([\d,]{4,})\s*units?\s*per month",
    "capacity_total":     r"(?:available capacity|network capacity)[^\d]{0,30}([\d,]{4,})",
    "rejection_rate_pct": r"batch rejection rate[^\d]{0,40}(\d+(?:\.\d+)?)\s*%",
    "capa_days":          r"(?:closure time|CAPA)[^\d]{0,40}(\d{1,3})\s*days?",
    "payment_terms":      r"\bNet\s*(\d{2,3})\b",
    "contract_years":     r"(\d)\s*(?:-|\s)?years?\b",
    "safety_stock_weeks": r"(\d{1,2})\s*weeks?\s*(?:of\s*)?safety stock",
}

DATE = re.compile(
    r"\b(January|February|March|April|May|June|July|August|September|"
    r"October|November|December)\s+(\d{1,2}),\s*(\d{4})\b", re.I)
MONTHS = {m: i + 1 for i, m in enumerate(
    ["january", "february", "march", "april", "may", "june", "july",
     "august", "september", "october", "november", "december"])}


def _num(s):
    return float(s.replace(",", ""))


def extract_facts(passages):
    facts, evidence = {}, {}
    for p in passages:
        for key, pat in PATTERNS.items():
            if key in facts:
                continue
            m = re.search(pat, p["text"], re.I)
            if m:
                facts[key] = _num(m.group(1))
                evidence[key] = {"pid": p["pid"], "section": p["section"],
                                 "quote": p["text"][:160]}
    for p in passages[:25]:
        m = DATE.search(p["text"])
        if m:
            facts["response_date"] = "%04d-%02d-%02d" % (
                int(m.group(3)), MONTHS[m.group(1).lower()], int(m.group(2)))
            evidence["response_date"] = {"pid": p["pid"], "quote": p["text"][:160]}
            break
    return facts, evidence


# ---------------------------------------------------------------- checks

def derived(facts, reg):
    """DRV- checks. Each returns (verdict, detail) or None when inputs absent."""
    out = {}
    vol = reg.get("monthly_volume")
    moq = facts.get("moq_units")
    if moq and vol:
        months = moq / float(vol)
        out["DRV-01"] = ("deviation" if months > 1 else "answered",
                         "MOQ %s = %.1f months of the %s/month requirement"
                         % (int(moq), months, vol))
    elif moq:
        out["DRV-01"] = ("not_evaluable",
                         "MOQ %s stated; RFP monthly volume unresolved" % int(moq))

    rfp_term = reg.get("contract_term_years")
    yrs = facts.get("contract_years")
    if yrs and rfp_term:
        out["DRV-02"] = ("answered" if yrs == rfp_term else "deviation",
                         "offered %d years against %d required" % (yrs, rfp_term))

    issued, deadline = reg.get("issued"), reg.get("deadline")
    rdate = facts.get("response_date")
    if rdate and issued and deadline:
        d = dt.date.fromisoformat(rdate)
        ok = dt.date.fromisoformat(issued) <= d <= dt.date.fromisoformat(deadline)
        out["DRV-04"] = ("answered" if ok else "deviation",
                         "response dated %s; window %s to %s"
                         % (rdate, issued, deadline))
    return out


def script_checks(facts, reg):
    """Evaluate engine=script requirements whose thresholds are resolved."""
    results = {}
    for r in reg.get("requirements", []):
        if r.get("engine") != "script":
            continue
        if r.get("status") == "UNRESOLVED":
            results[r["id"]] = ("not_evaluable", "threshold unresolved in the RFP")
            continue
        expr = r.get("assert", "")
        m = re.match(r"\s*(\w+)\s*(==|>=|<=|>|<)\s*'?([^'\s]+)'?\s*$", expr)
        if not m:
            continue
        field, op, want = m.groups()
        if field not in facts:
            results[r["id"]] = ("absent", "no value stated for %s" % field)
            continue
        got = facts[field]
        try:
            want_v = float(want)
        except ValueError:
            want_v = float(re.sub(r"\D", "", want) or 0)
        ok = {"==": got == want_v, ">=": got >= want_v, "<=": got <= want_v,
              ">": got > want_v, "<": got < want_v}[op]
        results[r["id"]] = ("answered" if ok else "deviation",
                            "%s = %s (required %s %s)" % (field, got, op, want))
    return results


# ---------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--register", required=True)
    ap.add_argument("--responses", nargs="+", required=True)
    ap.add_argument("-o", "--out", default="facts.json")
    a = ap.parse_args()

    with open(a.register, encoding="utf-8") as fh:
        reg = json.load(fh)
    req_ids = [r["id"] for r in reg.get("requirements", [])]

    report = {"rfp_ref": reg.get("rfp_ref"), "respondents": {}}
    for path in a.responses:
        if not os.path.exists(path):
            sys.exit("File not found: %s" % path)
        name = os.path.splitext(os.path.basename(path))[0]
        passages = parse_docx(path)
        facts, evidence = extract_facts(passages)
        checks = script_checks(facts, reg)
        checks.update(derived(facts, reg))
        report["respondents"][name] = {
            "passage_count": len(passages),
            "facts": facts,
            "evidence": evidence,
            "script_verdicts": {k: {"verdict": v[0], "detail": v[1]}
                                for k, v in checks.items()},
            "passages": passages,
        }

    # Completeness receipt - the model fills the rest; the grid proves the shape.
    n_req, n_res = len(req_ids), len(report["respondents"])
    report["receipt"] = {"requirements": n_req, "respondents": n_res,
                         "cells": n_req * n_res,
                         "script_filled": sum(
                             len(r["script_verdicts"])
                             for r in report["respondents"].values())}

    with open(a.out, "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2, ensure_ascii=False)

    print("Register : %s (%d requirements)" % (reg.get("rfp_ref"), n_req))
    for name, r in report["respondents"].items():
        print("\n%s - %d passages" % (name, r["passage_count"]))
        for k, v in sorted(r["facts"].items()):
            print("    %-20s %s" % (k, v))
        for rid, v in sorted(r["script_verdicts"].items()):
            print("    %-10s %-14s %s" % (rid, v["verdict"], v["detail"]))

    print("\nGrid: %d requirements x %d respondents = %d cells"
          % (n_req, n_res, n_req * n_res))
    print("Script filled %d; the model must fill the remainder - no cell may be empty."
          % report["receipt"]["script_filled"])
    print("Written to %s" % a.out)


if __name__ == "__main__":
    main()
