---
name: response-check
description: Checks supplier RFP responses against a confirmed requirement register — maps each requirement to the passage that answers it, grades the verdict, extracts stated figures, runs threshold and derived checks, and proves every requirement by respondent cell has been filled. Use after the register is confirmed, when the user asks to check, evaluate, score or compare submitted responses against an RFP.
---

# Check responses against the register

Takes `requirements.json` and every submission, and produces `coverage.json` —
one verdict per requirement per respondent, plus each respondent's additional
notes.

Do the script work in **one invocation**. The sandbox starts fresh on every run
and keeps nothing, so a parse written in one run is not visible to the next.

## Step 1 — parse and measure (script)

Run `scripts/check_responses.py` with the register and all response files. In
that single run it will:

- parse each response into passages with stable IDs
- extract stated figures — unit price, lead-time weeks, MOQ, capacity, %,
  rejection rate, CAPA days, payment terms, contract term, response date
- evaluate every `engine: script` requirement whose threshold is resolved
- compute the `DRV-` derived checks
- print the coverage grid — requirements × respondents

## Step 2 — map requirements to passages (you)

For each requirement and each respondent, find the passage that addresses it.

**Match on meaning, never on position.** Respondents answer in their own words
and their own outline. The same question number means different things in
different documents, and a requirement may be answered somewhere the RFP never
anticipated — a cover letter, a bid summary table, a timeline.

Three things follow:

- A requirement is satisfied from **anywhere** in the document.
- Never require the response to reproduce the RFP's structure. Most do not.
- Where a response has real heading styles, use them. Where it has only visual
  formatting, fall back to pattern matching, then to paragraph blocks.

If two passages address one requirement, cite the more specific one.

**Record a `stated_value` wherever the answer has one** — a price, a number of
weeks, a percentage, a term, a named outcome. The report uses it as the short
answer in the comparison table, so a reader can compare substance across
respondents at a glance. Where the answer is qualitative, keep the `extract`
short enough that its first clause stands alone.

## Step 3 — grade each verdict (you)

| Verdict | Meaning |
|---|---|
| `answered` | Specific, checkable commitment. |
| `partial` | Addressed, but missing a figure, date, name or commitment that was asked for. |
| `evasive` | Words occupy the space; no commitment. "Available on request", "details to follow". |
| `absent` | Nothing in the document addresses it. |
| `deviation` | A specific answer that conflicts with the requirement. Record both values. |

**Coverage is not conformance.** The verdict records whether the respondent
supplied what was asked. Whether the value *passes* is a separate test that
needs a threshold. Where a respondent answers fully but the register marks the
requirement `UNRESOLVED`, grade it `answered` and set `gate` to
`cannot_adjudicate` with a short reason — never `not_evaluable`, which would
penalise them for the RFP's own gap. Reserve `not_evaluable` for a derived
check that cannot be computed because an RFP input is missing.

Grade on substance. Never on tone, length or confidence. A blunt "we do not
offer this" is `answered`; a paragraph of enthusiasm with no number is not.

For `engine: model` requirements, apply the rubric in the register and quote
the span the judgement rests on. If the rubric's flag condition matches, return
`flag` and explain the tension — do not resolve it yourself.

## Step 4 — additional notes (you)

Anything a respondent offers that the register does not ask for goes to that
respondent's `additional_notes`. Typical: extra commercial sweeteners, timelines
nobody requested, performance records, capability claims.

Record them. Never let them fill a gap, and never score them. A respondent
cannot improve coverage by answering questions nobody asked.

## Step 5 — completeness receipt (script)

The script asserts that **every requirement × every respondent has a verdict**
and fails loudly if not. Print the arithmetic:

```
27 requirements x 3 respondents = 81 cells; 81 filled, 0 empty
   answered 44 | partial 11 | evasive 6 | absent 14 | deviation 6
   not evaluable: 3 (unresolved thresholds)
```

This line is what separates a checked stack from a read stack. Never report
results without it.

## Output schema

```json
{
  "cells": [
    { "req_id": "TERM-02",
      "respondent": "Annterra",
      "verdict": "deviation",
      "extract": "Payment Terms - Net 90",
      "location": "Bid Summary",
      "stated_value": "Net 90",
      "required_value": "Net 60" }
  ],
  "additional_notes": {
    "Annterra": [
      { "item": "Engineering batch charged at cost, fully credited against the first commercial order",
        "location": "Bid Summary" }
    ]
  },
  "receipt": { "requirements": 27, "respondents": 3, "cells": 81,
               "filled": 81, "not_evaluable": 3 }
}
```

## Do not

- Do not evaluate a requirement whose `status` is `UNRESOLVED`. Report the
  stated values and leave the verdict as `not_evaluable`.
- Do not comment on formatting, design or writing quality. Content only.
- Do not infer a commitment from a marketing claim. "Industry-leading turnaround"
  is not a lead time.
- Do not leave a cell empty. `absent` is a verdict; blank is a defect.
